﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using CountryPopulations.Models;
using Newtonsoft.Json;

namespace CountryPopulations
{
    class Program
    {
        static void Main(string[] args)
        {
            var searchCountry = Convert.ToString(Console.ReadLine());
            var MinPopulation = Convert.ToInt32(Console.ReadLine());

            var result = Result.CountryCountByCriteria(searchCountry, MinPopulation);
            Console.WriteLine(result);
        }
    }

    public class Result
    {
        private const string URL = "https://jsonmock.hackerrank.com/api/countries/search";
        
        public static int CountryCountByCriteria(string s, int p) {
           var result= GetCountryResponse(s, p);
            return result.Data.Count;
        }

        public static PageResult GetCountryResponse(string s, int p) {
            var pageresult = new PageResult();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            string urlParameters = $"?name={s}";
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue("application/json"));

            // List data response.
            HttpResponseMessage response = client.GetAsync(urlParameters).Result;  // Blocking call! Program will wait here until a response is received or a timeout occurs.
            if (response.IsSuccessStatusCode)
            {
                // Parse the response body.
                var dataObjects = response.Content.ReadAsStringAsync().Result;  //Make sure to add a reference to System.Net.Http.Formatting.dll
               
                var pageResultClient = JsonConvert.DeserializeObject<PageResult>(dataObjects);

                return pageResultClient;
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                return null;
            }

            //Make any other calls using HttpClient here.

            //Dispose once all HttpClient calls are complete. This is not necessary if the containing object will be disposed of; for example in this case the HttpClient instance will be disposed automatically when the application terminates so the following call is superfluous.
            client.Dispose();
        }
    }
}
